# CHANGELOG — LLM list price × public benchmarks

## 2026-11-22
- Added price snapshot_date 2026-11-22.
- All 9 snapshot_dates re-joined to Arena text/latest overall published 2026-11-19 (previous version: 2026-11-11). Hugging Face revision abbae57d7888.
- `arena_category_scores.csv` re-built from the same Arena release (coding, hard_prompts, expert), 201 rows.
- 67 models joined; 538 rows across 9 snapshot_dates. Columns of existing files unchanged.

## 2026-11-15
- Prices and the Arena release (published 2026-11-11, revision 4ca698d9bb57) are unchanged from the previous version.
- New file `arena_category_scores.csv`: Arena text category scores (coding, hard_prompts, expert) for the joined models from the same Arena release, 201 rows. Join to `price_benchmark_join.csv` on `model_id`.
- 67 models joined; 485 rows across 8 snapshot_dates. Columns of existing files unchanged.

## 2026-11-15
- Added price snapshot_date 2026-11-15.
- All 8 snapshot_dates re-joined to Arena text/latest overall published 2026-11-11 (previous version: 2026-11-06). Hugging Face revision 4ca698d9bb57.
- 67 models joined; 485 rows across 8 snapshot_dates. Columns unchanged.

## 2026-11-08
- Added price snapshot_date 2026-11-08.
- All 7 snapshot_dates re-joined to Arena text/latest overall published 2026-11-06 (previous version: 2026-10-28). Hugging Face revision f566816dfe80.
- 67 models joined; 432 rows across 7 snapshot_dates. Columns unchanged.

## 2026-11-01
- Added price snapshot_date 2026-11-01.
- All 6 snapshot_dates re-joined to Arena text/latest overall published 2026-10-28 (previous version: 2026-10-22). Hugging Face revision 323062f70843.
- 67 models joined; 379 rows across 6 snapshot_dates. Columns unchanged.

## 2026-10-27
- Added price snapshot_date 2026-10-25.
- All 5 snapshot_dates re-joined to Arena text/latest overall published 2026-10-22 (previous version: 2026-10-15). Hugging Face revision a467e6b989bd.
- Arena renamed 53 matched models (for example `claude-opus-4-8` → `Claude Opus 4.8`). Each rename was accepted only when organization matched, rating moved by less than 30 points and vote_count did not fall by more than 5%.
- New aliases: `claude-haiku-5-5` → `Claude Haiku 5.5 (High)`; `o1` → `o1 (2024-12-17)`.
- 67 models joined; 317 rows across 5 snapshot_dates. Columns unchanged.

## 2026-10-20
- Added price snapshot_dates **2026-10-11 & 2026-10-18**; all four snapshot_dates re-joined to Arena text/latest overall (**2026-10-15**, CC-BY-4.0).
- `model_id_crosswalk.csv`: Arena renamed 9 matched entries to display-style names (e.g. `claude-opus-5-max` → `Claude Opus 5 (Max)`, `kimi-k3-max` → `Kimi K3 (Max)`); targets updated.
- New curated aliases where both an official list price and an Arena overall row exist: Gemini 4 Argon, Claude Opus 5.5, Claude Sonnet 5.5, Mistral Large 4, Grok 4.7, plus earlier API ids whose Arena row is their single dated snapshot or single listed reasoning-effort variant.
- 65 models joined; 247 rows across 4 snapshot_dates. Columns unchanged.

## 2026-10-07
- Re-joined kaitoland list prices for snapshot_dates **2026-09-20 & 2026-10-04** to Arena text/latest overall (**2026-10-02**, CC-BY-4.0).
- Expanded curated alias_map (Gemini 3.6–3.8 flash, additional GPT-5.x/6.x, Grok, Mistral Large 3, Kimi K2.6) — only where official list prices exist.
- Schema adds: `arena_subset`, `cached_input_usd_per_1m`, `points_per_dollar_proxy` (unique dictionary descriptions).
- Multi-date `snapshot_index.csv` rows for MoM literacy notebooks.
- Still excluded: Wars mashups, Artificial Analysis scrapes, aggregator prices, invented FX/Qwen rows.

## 2026-09-20/21
- Living-series docs (SERIES/CHANGELOG/snapshot_index); bootstrap ~20-model join on 2026-09-20 prices × 2026-09-13 Arena.
