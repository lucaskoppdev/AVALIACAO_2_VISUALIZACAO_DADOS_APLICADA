# EXCLUSIONS — LLM list price × Arena score join

## Sources left out on purpose

| Candidate | License signal | Decision |
| --- | --- | --- |
| Open LLM Leaderboard (`open-llm-leaderboard/contents` on Hugging Face) | Dataset card declares no license; Kaggle MIT wrappers do not clear upstream redistribution | Not used. It also overlaps poorly with proprietary API model ids |
| Artificial Analysis and other closed aggregator scrapes | Redistribution rights unclear, even when a Kaggle mirror claims CC0 | Not used |
| `alitaqishah/llm-benchmark-wars-…` and similar multi-source mashups | Mixed upstream (Arena + Artificial Analysis + reports) | Not used |
| `sergionefedov/llm-benchmarks-and-capabilities-…` | Package license given, but the build mixes several sources and a generative pipeline | Not used |
| `waddahali/open-llm-leaderboard-history` | MIT on Kaggle; upstream Hugging Face contents carry no license | Not used |
| LMSYS Chatbot Arena conversation dumps | CC BY-NC (NonCommercial) | Not used |
| `riyagarg0314/ai-model-arena-rankings-2023-2026` | CC BY-SA 4.0 mirror of the official CC-BY-4.0 data | The official Hugging Face source is used instead |

## Rows left out on purpose

1. Priced models with no confident name match to an Arena `model_name`. No fuzzy joins are forced.
2. Models sold only through a third-party host on the price side (for example Z.ai GLM hosted by Mistral, or open-weight models hosted by Groq). Their Arena rows describe the upstream model, not the hosted SKU.
3. API ids whose Arena listing has several dated snapshots or several reasoning-effort variants with no single obvious target (for example `gpt-4o`, `gemini-3-flash-preview`).
4. Embedding, moderation, search and image models, which have no Arena text-overall score.
5. Discounts that are not posted list prices. FX or JPY columns (USD list prices only).
6. Any claim that Arena scores are vendor benchmarks. They are community preference ratings published under CC-BY-4.0.
