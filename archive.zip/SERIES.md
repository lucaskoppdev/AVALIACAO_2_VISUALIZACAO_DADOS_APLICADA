# SERIES — how this price × Arena join is maintained

## What you get

- **List prices** from `kaitoland/latest-llm-api-pricing-snapshot` (official vendor pricing pages; USD per 1M tokens).
- **Arena text-overall scores** from Hugging Face `lmarena-ai/leaderboard-dataset` (CC-BY-4.0).

Main table: `price_benchmark_join.csv`. Key: `snapshot_date` + `model_id`, with one preferred `price_tier` per model.
Inventory: `snapshot_index.csv`.

## Current contents (2026-11-22)

- Price snapshot_dates: 2026-09-20, 2026-10-04, 2026-10-11, 2026-10-18, 2026-10-25, 2026-11-01, 2026-11-08, 2026-11-15, 2026-11-22
- Arena leaderboard_publish_date: 2026-11-19 (all snapshot_dates are re-joined to this one score vintage)
- Arena category scores (coding, hard_prompts, expert): 201 rows in `arena_category_scores.csv`, same release
- 67 models from 7 providers, 538 rows

## Cadence

| Step | When | What happens |
| --- | --- | --- |
| Price batch | Sunday 10:00 JST, in the sibling pricing dataset | New `snapshot_date` rows of list prices |
| This join | Weekly, after the sibling update | All price dates re-joined to the newest Arena overall table; new Kaggle version; `CHANGELOG.md` entry |

Because every version re-joins to the newest Arena table, Arena columns describe the score vintage in `arena_leaderboard_publish_date`, not the price date.

## Starter code

```python
import pandas as pd
root = "/kaggle/input/llm-list-price-meets-public-benchmarks"
join = pd.read_csv(f"{root}/price_benchmark_join.csv")
latest = join[join.snapshot_date == join.snapshot_date.max()]
latest.sort_values("points_per_dollar_proxy", ascending=False)[
    ["model_display_name", "input_usd_per_1m", "output_usd_per_1m", "arena_rating", "points_per_dollar_proxy"]].head(10)
```

## Comparing two price dates

Join two `snapshot_date` slices on `model_id`. A key present in one slice only means the vendor added or removed that SKU on its pricing page, or the price row has no Arena match that week.

## Files

| File | Role |
| --- | --- |
| `price_benchmark_join.csv` | Price × Arena rows |
| `snapshot_index.csv` | Row and model counts per snapshot_date |
| `model_id_crosswalk.csv` | `model_id` → Arena `model_name` |
| `price_snapshots_subset.csv` | All price tiers for the joined models |
| `arena_scores_attributed.csv` | Arena overall rows used (CC-BY-4.0) |
| `arena_category_scores.csv` | Arena coding, hard_prompts and expert scores for the same models (CC-BY-4.0) |
| `data_dictionary.csv` | Column definitions |
| `CHANGELOG.md` | Version history |
| `sources.md` / `EXCLUSIONS.md` | Provenance and intentional gaps |

List prices and Arena preference ratings are not financial advice or vendor quality guarantees. Check the official pricing pages before buying.
