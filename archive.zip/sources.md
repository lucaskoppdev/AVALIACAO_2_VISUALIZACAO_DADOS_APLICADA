# Sources — LLM list price × Arena score join

## Price side

- Dataset: `kaitoland/latest-llm-api-pricing-snapshot`, refreshed every Sunday 10:00 JST.
- Content: list prices copied from official vendor pricing pages, in USD per 1M tokens. Figures remain the vendors' published facts; this compilation is not endorsed by any vendor.
- Price dates in this version: 2026-09-20, 2026-10-04, 2026-10-11, 2026-10-18, 2026-10-25, 2026-11-01, 2026-11-08, 2026-11-15, 2026-11-22.

## Score side

- Source: Hugging Face `lmarena-ai/leaderboard-dataset`, config `text`, split `latest`, `category == overall`.
- Revision used: `abbae57d7888809e8b686f8548a6f77c81fa03f4`; leaderboard_publish_date 2026-11-19.
- License: CC-BY-4.0 (dataset card `license: cc-by-4.0`).
- Attribution (required by CC-BY-4.0):
  > Arena leaderboard scores © Arena / LMArena contributors, sourced from
  > https://huggingface.co/datasets/lmarena-ai/leaderboard-dataset
  > licensed under Creative Commons Attribution 4.0 International (CC BY 4.0).

## Join method

1. `model_id_crosswalk.csv` maps each priced API id to one Arena `model_name`.
2. Mapping rules: exact normalized name, or a curated alias when Arena lists exactly one variant for that API id (one dated snapshot, or one reasoning-effort setting such as High or Max).
3. When Arena renames a model, the key follows the new name only if organization matches, the rating moves by less than 30 points and vote_count does not drop by more than 5%.
4. For each priced model the preferred tier is standard (or off_peak), then long-context, batch, flex, fast, priority, peak.
5. `arena_category_scores.csv` takes rows with `category` in coding, hard_prompts, expert from the same config, split and revision, matched by the same `arena_model_name` as the crosswalk. 201 rows.
6. `scenario_10k_1k_usd` = input price × 0.01 + output price × 0.001 (10,000 input and 1,000 output tokens). `points_per_dollar_proxy` = `arena_rating` ÷ that cost.

This version: 67 models, 538 rows. See `EXCLUSIONS.md` for what was left out and why.
